# algo-trading-strategies
Algorithmic Trading Startegies with Python and MetaTrader5
